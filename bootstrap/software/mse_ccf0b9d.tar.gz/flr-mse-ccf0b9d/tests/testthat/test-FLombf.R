# test-FLombf.R - DESC
# /test-FLombf.R

# Copyright Iago MOSQUEIRA (WMR), 2021
# Author: Iago MOSQUEIRA (WMR) <iago.mosqueira@wur.nl>
#
# Distributed under the terms of the EUPL-1.2


data(cjm)


# --- FLombf om

is(om)

# ACCESSORS

is(biols(om))

length(biols(om))

names(biols(om))

is(fisheries(om))
